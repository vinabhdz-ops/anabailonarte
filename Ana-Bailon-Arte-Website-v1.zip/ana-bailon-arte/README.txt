ANA BAILÓN ARTE — WEBSITE V1

1. Open index.html in a browser to preview the site.
2. Replace placeholder painting names, sizes, media and prices in the `works` array near the bottom of index.html.
3. Replace YOUR-EMAIL@example.com with the email you want purchase inquiries sent to.
4. Later, replace each colored placeholder with real painting photos and connect secure hosted checkout links.

GITHUB PAGES
- Create a GitHub account/repository.
- Upload index.html.
- Repository Settings > Pages > Deploy from a branch > main / root.
- GitHub will provide the public Pages URL.
